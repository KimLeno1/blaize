/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Morrow: Floating 2D Anime-Style Desktop Companion Window (v3)
 *
 * Memory & Living Desktop Governance:
 * 1. Minimal Bundle: Plain TypeScript + Bundled 2D Layered Anime SVG Rig (/assets/morrow-rig/*.svg).
 * 2. Real Sit / Run / Dance / Work / Celebrate / Sleep Animation State Machine:
 *    - Stops animation loops (0 FPS) when resting/sleeping or when reducedMotion is enabled.
 *    - Immediate interrupt ("Stop") halts motion cleanly.
 * 3. Voice & Music Integration:
 *    - Push-to-Talk default; local wake-word off by default (0 MB).
 *    - Quick controls for Sit, Run, Dance, Stop, and opening the 2D Asset File Manager & Music Player.
 */

import React, { useState } from 'react';
import {
  MorrowState,
  PersonalityId,
  TalkDecisionLog,
} from '../packages/contracts';
import { PERSONALITY_PACKS } from '../packages/core';
import {
  MORROW_2D_RIG_CLIPS,
  MorrowAnimationAction,
  routeNaturalLanguageAnimationCommand,
} from '../packages/living';

interface MorrowCompanionProps {
  morrowState: MorrowState;
  setMorrowState: (s: MorrowState) => void;
  personalityId: PersonalityId;
  setPersonalityId: (p: PersonalityId) => void;
  talkLogs: TalkDecisionLog[];
  focusMode: boolean;
  setFocusMode: (v: boolean) => void;
  onDismissNotification: () => void;
  dismissalCount: number;
  pendingApproval: {
    id: string;
    title: string;
    target: string;
    risk: string;
    evidenceHash: string;
    amount?: string;
    reason: string;
  } | null;
  onApproveAction: (channel: 'local_sheet' | 'telegram_phone') => void;
  onRejectAction: () => void;
  onRecordUserCorrection: (correctionText: string, promoteToRule: boolean) => void;
  onSubmitVoiceMission: (transcript: string) => void;
  // v3 Living Companion Props
  companionName?: string;
  activeAnimAction?: MorrowAnimationAction;
  onChangeAnimAction?: (action: MorrowAnimationAction, reason?: string) => void;
  isPlayingMusic?: boolean;
  onToggleMusic?: () => void;
  onOpenStudioFileManager?: () => void;
}

export const MorrowCompanion: React.FC<MorrowCompanionProps> = ({
  morrowState,
  setMorrowState,
  personalityId,
  setPersonalityId,
  talkLogs,
  focusMode,
  setFocusMode,
  onDismissNotification,
  dismissalCount,
  pendingApproval,
  onApproveAction,
  onRejectAction,
  onRecordUserCorrection,
  onSubmitVoiceMission,
  companionName = 'Morrow',
  activeAnimAction = 'idle',
  onChangeAnimAction,
  isPlayingMusic = false,
  onToggleMusic,
  onOpenStudioFileManager,
}) => {
  const [hidden, setHidden] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [dockPosition, setDockPosition] = useState<'bottom-right' | 'bottom-left'>('bottom-right');

  // Voice & Wake-Word State (Requirement #8: No Python sidecar by default; Push-to-Talk default)
  const [voiceOptIn, setVoiceOptIn] = useState(true);
  const [wakeWordOptIn, setWakeWordOptIn] = useState(false);
  const [isRecordingPtt, setIsRecordingPtt] = useState(false);
  const [voiceDisabled, setVoiceDisabled] = useState(false);
  const [transcriptDraft, setTranscriptDraft] = useState(
    'Reconcile October Ghana MoMo statement and check Safe-to-Spend'
  );
  const [showTranscriptConfirm, setShowTranscriptConfirm] = useState(false);

  // User Correction Input
  const [correctionInput, setCorrectionInput] = useState('');
  const [promoteCorrection, setPromoteCorrection] = useState(true);
  const [quickAnimInput, setQuickAnimInput] = useState('');

  const personalityList = Object.values(PERSONALITY_PACKS);

  // Determine active 2D rig clip from /assets/morrow-rig/manifest.json
  const currentClip =
    MORROW_2D_RIG_CLIPS.find((c) => c.action === activeAnimAction) ||
    (morrowState === 'resting'
      ? MORROW_2D_RIG_CLIPS.find((c) => c.action === 'sleep_rest')!
      : morrowState === 'working' || morrowState === 'verifying'
      ? MORROW_2D_RIG_CLIPS.find((c) => c.action === 'work_type')!
      : morrowState === 'done_with_proof'
      ? MORROW_2D_RIG_CLIPS.find((c) => c.action === 'celebrate')!
      : MORROW_2D_RIG_CLIPS[0]);

  const animationLoopStopped =
    morrowState === 'resting' || activeAnimAction === 'sleep_rest' || reducedMotion;

  const triggerClip = (action: MorrowAnimationAction, reason?: string) => {
    if (onChangeAnimAction) {
      onChangeAnimAction(action, reason);
    }
    if (action === 'sleep_rest') {
      setMorrowState('resting');
    } else if (action === 'work_type') {
      setMorrowState('working');
    } else if (action === 'celebrate') {
      setMorrowState('done_with_proof');
    } else if (morrowState === 'resting') {
      setMorrowState('attentive');
    }
  };

  if (hidden) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <button
          type="button"
          onClick={() => setHidden(false)}
          aria-label={`Restore ${companionName} Companion Window`}
          className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900/95 border border-sky-500/40 text-xs font-mono text-sky-300 shadow-lg hover:bg-slate-800 transition-colors"
        >
          <span className="w-2 h-2 rounded-full bg-sky-400" />
          Restore {companionName} ({currentClip.action})
        </button>
      </div>
    );
  }

  const positionClasses =
    dockPosition === 'bottom-right' ? 'bottom-4 right-4' : 'bottom-4 left-4';

  const handlePttClick = () => {
    if (voiceDisabled || !voiceOptIn) return;
    if (!isRecordingPtt) {
      setIsRecordingPtt(true);
      setMorrowState('listening');
      triggerClip('listen_speak');
      setTimeout(() => {
        setIsRecordingPtt(false);
        setShowTranscriptConfirm(true);
        setMorrowState('thinking');
      }, 600);
    }
  };

  const latestTalk = talkLogs[0];

  return (
    <>
      {/* Local + Remote Phone Approval Sheet Modal */}
      {pendingApproval && (
        <div
          id="approval-sheet-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby="approval-sheet-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-lg bg-[#0F1623] border border-amber-500/50 rounded-xl shadow-2xl p-6 space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-mono text-amber-400 uppercase tracking-wider">
                  TRUST KERNEL · EXPLICIT USER APPROVAL GATE
                </p>
                <h2 id="approval-sheet-title" className="text-lg font-bold text-slate-100 mt-1">
                  {pendingApproval.title}
                </h2>
              </div>
              <span className="px-2.5 py-1 rounded bg-amber-500/15 border border-amber-500/40 text-xs font-mono text-amber-300">
                RISK: {pendingApproval.risk.toUpperCase()}
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Target / Endpoint:</span>
                <span className="text-slate-200">{pendingApproval.target}</span>
              </div>
              {pendingApproval.amount && (
                <div className="flex justify-between">
                  <span className="text-slate-400">Draft Amount:</span>
                  <span className="text-emerald-400 font-semibold">{pendingApproval.amount}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-400">Evidence Hash:</span>
                <span className="text-sky-300">{pendingApproval.evidenceHash}</span>
              </div>
              <div className="pt-2 border-t border-slate-800 text-slate-300 font-sans">
                {pendingApproval.reason}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={onRejectAction}
                className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors"
              >
                Deny &amp; Halt Step
              </button>
              <button
                type="button"
                onClick={() => onApproveAction('telegram_phone')}
                className="px-3.5 py-2 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-xs font-medium text-sky-200 transition-colors"
              >
                Approve via Phone (Telegram Bot)
              </button>
              <button
                type="button"
                onClick={() => onApproveAction('local_sheet')}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-xs font-semibold text-slate-950 transition-colors"
              >
                Approve on Local Sheet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Morrow 2D Anime Companion Surface */}
      <aside
        aria-label={`${companionName} Accountable 2D Anime Companion`}
        data-loop-state={animationLoopStopped ? 'stopped_0fps' : 'active'}
        data-active-clip={currentClip.clipId}
        className={`fixed ${positionClasses} z-40 ${
          expanded ? 'w-[390px] sm:w-[436px]' : 'w-[368px]'
        } bg-[#0E1522]/95 backdrop-blur-md border border-slate-700/90 rounded-xl shadow-2xl`}
      >
        {/* Companion Top Header with Real 2D Anime Rig Avatar */}
        <div className="flex items-center justify-between gap-2 px-3.5 py-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
            {/* Real 2D Anime Girl Layered SVG Rig from /assets/morrow-rig/ */}
            <div
              onClick={() => {
                if (onOpenStudioFileManager) onOpenStudioFileManager();
              }}
              className="relative w-11 h-12 rounded-lg bg-slate-950 border border-sky-500/40 flex items-center justify-center shrink-0 cursor-pointer overflow-hidden"
              title={`${companionName} 2D Rig: ${currentClip.label} (${animationLoopStopped ? '0 FPS' : `${currentClip.fps} FPS`}) — Click to open 2D Asset File Manager`}
            >
              <img
                src={currentClip.file}
                alt={`${companionName} 2D anime avatar (${currentClip.action})`}
                className="w-10 h-11 object-contain"
              />
            </div>

            <div className="min-w-0 flex-1 overflow-hidden">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-100 truncate">
                <span>{companionName}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="font-mono text-[11px] text-sky-300 truncate">
                  {currentClip.action} ({animationLoopStopped ? '0 FPS' : `${currentClip.fps} FPS`})
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                {animationLoopStopped
                  ? 'Loop: STOPPED (0 FPS) · Resting'
                  : latestTalk
                  ? latestTalk.message || latestTalk.reason
                  : currentClip.label}
              </p>
            </div>
          </div>

          {/* Minimal Window Controls */}
          <div className="flex items-center gap-1 shrink-0 font-mono text-xs">
            <button
              type="button"
              onClick={() => setVoiceDisabled(!voiceDisabled)}
              aria-label={voiceDisabled ? 'Enable microphone controls' : 'Immediate disable microphone'}
              className={`px-1.5 py-1 rounded text-[11px] transition-colors ${
                voiceDisabled
                  ? 'text-rose-400 bg-rose-950/50 hover:bg-rose-900/50'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {voiceDisabled ? 'Mic:OFF' : 'Mic'}
            </button>
            <button
              type="button"
              onClick={() =>
                setDockPosition(dockPosition === 'bottom-right' ? 'bottom-left' : 'bottom-right')
              }
              aria-label="Switch companion dock corner"
              className="px-1.5 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-[11px]"
            >
              Dock
            </button>
            <button
              type="button"
              onClick={() => setExpanded(!expanded)}
              aria-label={expanded ? 'Collapse companion details' : 'Expand companion settings'}
              className="px-1.5 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-[11px]"
            >
              {expanded ? 'Less' : 'More'}
            </button>
            <button
              type="button"
              onClick={() => setHidden(true)}
              aria-label="Hide Morrow companion"
              className="px-1.5 py-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-[11px]"
            >
              Hide
            </button>
          </div>
        </div>

        {/* Quick 2D Anime Rig Actions (Sit, Run, Dance, Stop, Music, File Manager) */}
        <div className="px-3.5 py-2 flex flex-wrap items-center justify-between gap-1.5 text-xs bg-slate-900/60 border-b border-slate-800/80">
          <div className="flex items-center gap-1 font-mono text-[11px]">
            {(
              [
                { act: 'sit', label: 'Sit' },
                { act: 'run', label: 'Run' },
                { act: 'dance', label: 'Dance' },
                { act: 'sleep_rest', label: 'Rest' },
                { act: 'idle', label: '■ Stop' },
              ] as Array<{ act: MorrowAnimationAction; label: string }>
            ).map((b) => (
              <button
                key={b.act}
                type="button"
                onClick={() => triggerClip(b.act, `Companion bar action: ${b.act}`)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  activeAnimAction === b.act
                    ? 'bg-sky-400 text-slate-950 font-semibold'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {b.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1">
            {onToggleMusic && (
              <button
                type="button"
                onClick={onToggleMusic}
                className={`px-2 py-0.5 rounded font-mono text-[11px] border ${
                  isPlayingMusic
                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                    : 'bg-slate-800 border-slate-700 text-slate-300'
                }`}
              >
                {isPlayingMusic ? '♫ Pause' : '♫ Play'}
              </button>
            )}
            {onOpenStudioFileManager && (
              <button
                type="button"
                onClick={onOpenStudioFileManager}
                className="px-2 py-0.5 rounded font-mono text-[11px] bg-sky-500/20 border border-sky-500/40 text-sky-300 hover:bg-sky-500/30"
                title="Open 2D Rig File Manager, Music Player, Personality & Scheduler Studio"
              >
                2D Assets
              </button>
            )}
          </div>
        </div>

        {/* Bottom Status & Push-to-Talk Row */}
        <div className="px-3.5 py-2 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setFocusMode(!focusMode)}
              className={`px-2 py-1 rounded font-mono text-[11px] border transition-colors ${
                focusMode
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Focus Mode: {focusMode ? 'ON' : 'Off'}
            </button>
          </div>

          <button
            type="button"
            disabled={voiceDisabled || !voiceOptIn}
            onClick={handlePttClick}
            className={`px-2.5 py-1 rounded font-mono text-[11px] transition-colors ${
              voiceDisabled || !voiceOptIn
                ? 'bg-slate-900 text-slate-600 cursor-not-allowed'
                : isRecordingPtt
                ? 'bg-rose-500 text-white'
                : 'bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40'
            }`}
          >
            {voiceDisabled ? 'Voice Off' : isRecordingPtt ? 'Listening...' : 'Push-to-Talk'}
          </button>
        </div>

        {/* Voice Transcript Confirmation Drawer */}
        {showTranscriptConfirm && !voiceDisabled && (
          <div className="p-3 bg-slate-950 border-t border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between font-mono text-[11px] text-sky-400">
              <span>ASR TRANSCRIPT (muse-voice-transcribe-1.0)</span>
              <span>CONFIRM BEFORE RUN</span>
            </div>
            <input
              type="text"
              value={transcriptDraft}
              onChange={(e) => setTranscriptDraft(e.target.value)}
              aria-label="Edit voice transcript before running mission"
              className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-100"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowTranscriptConfirm(false);
                  setMorrowState('attentive');
                }}
                className="px-2.5 py-1 rounded bg-slate-800 text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowTranscriptConfirm(false);
                  onSubmitVoiceMission(transcriptDraft);
                }}
                className="px-3 py-1 rounded bg-sky-500 text-slate-950 font-semibold"
              >
                Run Verified Mission
              </button>
            </div>
          </div>
        )}

        {/* Expanded Companion Studio & Diagnostics */}
        {expanded && (
          <div className="p-3.5 border-t border-slate-800 space-y-3.5 text-xs bg-slate-950/90 rounded-b-xl max-h-[68vh] overflow-y-auto">
            {/* Natural-Language Animation Command Bar */}
            <div className="space-y-1.5">
              <label className="block font-mono text-[11px] text-slate-400">
                NATURAL-LANGUAGE ANIMATION COMMAND (0 TOKENS):
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={quickAnimInput}
                  onChange={(e) => setQuickAnimInput(e.target.value)}
                  placeholder='e.g. "Morrow, sit down" or "Dance to this song"'
                  className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200"
                />
                <button
                  type="button"
                  onClick={() => {
                    const res = routeNaturalLanguageAnimationCommand(quickAnimInput);
                    if (res.recognized && res.action) {
                      triggerClip(res.action, res.explanation);
                    }
                    setQuickAnimInput('');
                  }}
                  className="px-2.5 py-1.5 rounded bg-sky-500 text-slate-950 font-semibold"
                >
                  Go
                </button>
              </div>
            </div>

            {/* Personality Switcher */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] text-slate-400">
                  STARTER PERSONALITY (SAME TRUST KERNEL):
                </span>
                <span className="font-mono text-[10px] text-emerald-400">GUARD IMMUTABLE</span>
              </div>
              <div className="grid grid-cols-5 gap-1">
                {personalityList.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPersonalityId(p.id)}
                    className={`py-1 px-1.5 rounded text-[11px] font-medium border transition-colors ${
                      personalityId === p.id
                        ? 'bg-sky-500/20 border-sky-400 text-sky-200'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {p.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Reduced Motion & Python Wake-Word Sidecar Controls */}
            <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-[11px]">
                <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={reducedMotion}
                    onChange={(e) => setReducedMotion(e.target.checked)}
                    className="rounded border-slate-700"
                  />
                  Reduced Motion (0 FPS)
                </label>
                <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={wakeWordOptIn}
                    onChange={(e) => setWakeWordOptIn(e.target.checked)}
                    className="rounded border-slate-700"
                  />
                  Wake Word (Opt-In)
                </label>
              </div>
              <div className="text-[11px] font-mono text-slate-400">
                Python Wake-Word Sidecar:{' '}
                <span className={wakeWordOptIn ? 'text-amber-300' : 'text-emerald-400'}>
                  {wakeWordOptIn ? 'OPT-IN ACTIVE' : 'OFF BY DEFAULT (0 MB)'}
                </span>
              </div>
            </div>

            {/* Teach Morrow / Promote Correction to Standing Rule */}
            <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
              <span className="font-mono text-[11px] text-slate-400">
                RECORD USER CORRECTION → STANDING RULE
              </span>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={correctionInput}
                  onChange={(e) => setCorrectionInput(e.target.value)}
                  placeholder="e.g., Always categorize Makola Market under Inventory"
                  className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!correctionInput.trim()) return;
                    onRecordUserCorrection(correctionInput.trim(), promoteCorrection);
                    setCorrectionInput('');
                  }}
                  className="px-2.5 py-1.5 rounded bg-emerald-500 text-slate-950 font-semibold whitespace-nowrap"
                >
                  Save
                </button>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={promoteCorrection}
                    onChange={(e) => setPromoteCorrection(e.target.checked)}
                    className="rounded border-slate-700"
                  />
                  Promote to active Standing Rule
                </label>
                <button
                  type="button"
                  onClick={onDismissNotification}
                  className="text-slate-400 hover:text-slate-200 underline"
                >
                  Dismiss ({dismissalCount})
                </button>
              </div>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
