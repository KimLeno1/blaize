/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Blaize: The Accountable Living AI Desktop (v3)
 * Cross-platform desktop AI environment with Trust Kernel, hash-chained MemoryLedger,
 * Blaize Browser + Teach & Replay, L3xi Global Money Assistant, Meta Model Router,
 * Floating 2D Anime Companion (Morrow) with Bundled CC0 2D Rig Assets in File Manager,
 * Natural-Language Personality Studio, Dedicated Music Player + Dance Sync, and Scheduled Missions.
 *
 * Memory-Efficiency Requirement #4: Secondary feature modules (BlaizeBrowserView,
 * L3xiFinanceView, TrustAndLedgerView, EvalsAndSleepView, LivingDesktopStudioPanel)
 * are lazy-loaded via React.lazy() + Suspense only when opened.
 */

import React, { Suspense, lazy, useMemo, useRef, useState } from 'react';
import { MissionControlView } from './components/MissionControlView';
import { MorrowCompanion } from './components/MorrowCompanion';
import {
  BrowserProfileId,
  CompiledSkill,
  MissionState,
  MoneyActionDraft,
  MorrowState,
  PersonalityId,
  PolicyDecision,
  TalkDecisionLog,
} from './packages/contracts';
import {
  BoundedRingBuffer,
  DEFAULT_COMPILED_SKILL,
  DemoScenarioId,
  SleepCycleReport,
  buildMissionForScenario,
  evaluateMorrowTalkPolicy,
  executeSleepCycle,
} from './packages/core';
import {
  CompiledPersonalityProfile,
  DEFAULT_LOCAL_MUSIC_TRACKS,
  MorrowAnimationAction,
  MusicTrackItem,
  ScheduledMissionRecord,
  compileNaturalLanguagePersonality,
} from './packages/living';
import {
  DEFAULT_POLICY_CONFIG,
  MemoryLedger,
  PolicyConfig,
  computeDeterministicHash,
} from './packages/trust';

// Lazy-loaded Feature Modules (Requirement #4: Load into memory only when opened)
const BlaizeBrowserView = lazy(() =>
  import('./components/BlaizeBrowserView').then((m) => ({ default: m.BlaizeBrowserView }))
);
const L3xiFinanceView = lazy(() =>
  import('./components/L3xiFinanceView').then((m) => ({ default: m.L3xiFinanceView }))
);
const TrustAndLedgerView = lazy(() =>
  import('./components/TrustAndLedgerView').then((m) => ({ default: m.TrustAndLedgerView }))
);
const EvalsAndSleepView = lazy(() =>
  import('./components/EvalsAndSleepView').then((m) => ({ default: m.EvalsAndSleepView }))
);
const LivingDesktopStudioPanel = lazy(() =>
  import('./components/LivingDesktopStudioPanel').then((m) => ({
    default: m.LivingDesktopStudioPanel,
  }))
);

type ActiveWorkspaceTab =
  | 'mission_control'
  | 'blaize_browser'
  | 'l3xi_finance'
  | 'trust_ledger'
  | 'evals_sleep';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveWorkspaceTab>('mission_control');

  // Persistent Memory-Effective Instances (Single Allocation per Session)
  const ledgerRef = useRef<MemoryLedger | null>(null);
  if (!ledgerRef.current) {
    ledgerRef.current = new MemoryLedger(true);
  }
  const ledger = ledgerRef.current;

  const ringBufferRef = useRef<BoundedRingBuffer<string> | null>(null);
  if (!ringBufferRef.current) {
    const rb = new BoundedRingBuffer<string>(32);
    rb.push('boot: Trust Kernel initialized');
    rb.push('router: Verified Oct 2026 Meta Model API endpoints');
    rb.push('rig-2d: Loaded CC0 2D Anime Rig manifest (/assets/morrow-rig/manifest.json)');
    rb.push('mem-gov: <24 GB RAM profile active (Local LLM 0 MB, SQLite WAL+FTS5 only)');
    ringBufferRef.current = rb;
  }
  const ringBuffer = ringBufferRef.current;

  const [ledgerVersion, setLedgerVersion] = useState(0);
  const bumpLedger = () => setLedgerVersion((v) => v + 1);

  // Policy & Profile State
  const [policyConfig, setPolicyConfig] = useState<PolicyConfig>(DEFAULT_POLICY_CONFIG);
  const [compiledSkill, setCompiledSkill] = useState<CompiledSkill>(DEFAULT_COMPILED_SKILL);

  // Mission & Companion State
  const [activeScenario, setActiveScenario] = useState<DemoScenarioId>('normal_run');
  const [personalityId, setPersonalityId] = useState<PersonalityId>('morrow');

  // v3 Living Companion, 2D Rig, Personality Studio & Music Player State
  const [companionName, setCompanionName] = useState<string>('Morrow');
  const [activeLookId, setActiveLookId] = useState<string>('look-cyber-indigo');
  const [activeAnimAction, setActiveAnimAction] = useState<MorrowAnimationAction>('idle');
  const [compiledPersonality, setCompiledPersonality] = useState<CompiledPersonalityProfile>(() =>
    compileNaturalLanguagePersonality({
      name: 'Morrow',
      rawDescription:
        'Make her cheerful and teasing but respectful, talk like a clever anime sidekick, be quiet during work, celebrate verified accomplishments, and ask before starting a new task.',
      lookId: 'look-cyber-indigo',
      version: 1,
    })
  );
  const [isPlayingMusic, setIsPlayingMusic] = useState<boolean>(false);
  const [activeTrack, setActiveTrack] = useState<MusicTrackItem>(DEFAULT_LOCAL_MUSIC_TRACKS[0]);
  const [danceSyncEnabled, setDanceSyncEnabled] = useState<boolean>(true);

  const initialBundle = useMemo(
    () => buildMissionForScenario('normal_run', 'morrow'),
    []
  );
  const [mission, setMission] = useState(initialBundle.mission);
  const [morrowState, setMorrowState] = useState<MorrowState>(initialBundle.morrowState);
  const [talkLogs, setTalkLogs] = useState<TalkDecisionLog[]>([initialBundle.talkDecision]);
  const [focusMode, setFocusMode] = useState(false);
  const [dismissalCount, setDismissalCount] = useState(0);

  // Local + Remote Phone Approval Sheet State
  const [pendingApproval, setPendingApproval] = useState<{
    id: string;
    title: string;
    target: string;
    risk: string;
    evidenceHash: string;
    amount?: string;
    reason: string;
    draftId?: string;
  } | null>(null);
  const [approvedDraftIds, setApprovedDraftIds] = useState<string[]>([]);

  // Sleep Cycle Report State
  const [sleepReport, setSleepReport] = useState<SleepCycleReport>(() =>
    executeSleepCycle(ledger)
  );

  // Trigger 2D Rig Animation Action
  const handleTriggerAnimationAction = (action: MorrowAnimationAction, reason?: string) => {
    setActiveAnimAction(action);
    ringBuffer.push(`2d_rig:${action} (${reason || 'user command'})`);
    if (action === 'sleep_rest') {
      setMorrowState('resting');
    } else if (action === 'celebrate') {
      setMorrowState('done_with_proof');
    } else if (action === 'work_type') {
      setMorrowState('working');
    }
  };

  // Select Scenario Handler
  const handleSelectScenario = (scenario: DemoScenarioId) => {
    setActiveScenario(scenario);
    const next = buildMissionForScenario(scenario, personalityId);
    setMission(next.mission);
    setMorrowState(next.morrowState);
    if (scenario === 'normal_run') {
      setActiveAnimAction('celebrate');
    } else if (scenario === 'adversarial_run' || scenario === 'failed_action_recovery') {
      setActiveAnimAction('uncertain_concerned');
    } else if (scenario === 'credential_takeover') {
      setActiveAnimAction('waiting_approval');
    }

    const effectiveTalk = evaluateMorrowTalkPolicy({
      trigger: next.talkDecision.trigger,
      focusModeActive: focusMode,
      dismissalCountForCategory: dismissalCount,
      proposedMessage: next.talkDecision.message || next.talkDecision.reason,
    });
    setTalkLogs((prev) => [effectiveTalk, ...prev.slice(0, 15)]);

    ringBuffer.push(`scenario:${scenario} -> state:${next.mission.state}`);
    ledger.appendEvent({
      actor: 'agent',
      type:
        scenario === 'adversarial_run'
          ? 'action_blocked'
          : scenario === 'credential_takeover'
          ? 'credential_takeover'
          : 'mission_started',
      summary: `Executed scenario '${scenario}': ${next.mission.resultSummary || next.mission.objective}`,
      payload: JSON.stringify({
        scenario,
        state: next.mission.state,
        checkpoints: next.mission.checkpoints,
      }),
      trustLevel: 'verified_by_evidence',
      missionId: next.mission.id,
    });
    bumpLedger();
  };

  // Update Mission State Idempotently
  const handleUpdateMissionState = (newState: MissionState) => {
    setMission((prev) => ({
      ...prev,
      state: newState,
      updatedAt: new Date().toISOString(),
    }));
    ringBuffer.push(`mission_state_transition:${newState}`);

    if (newState === 'CANCELLED') {
      setMorrowState('resting');
      setActiveAnimAction('sleep_rest');
    } else if (newState === 'WAITING_FOR_USER') {
      setMorrowState('asking_approval');
      setActiveAnimAction('waiting_approval');
    } else if (newState === 'PLANNING') {
      setMorrowState('thinking');
      setActiveAnimAction('think_read');
    } else if (newState === 'RUNNING') {
      setMorrowState('working');
      setActiveAnimAction('work_type');
    } else if (newState === 'COMPLETED') {
      setMorrowState('done_with_proof');
      setActiveAnimAction('celebrate');
    }
    bumpLedger();
  };

  // Trigger Approval Modal
  const handleRequestApproval = (
    title: string,
    target: string,
    risk: string,
    reason: string,
    draftId?: string
  ) => {
    const evidenceHash = computeDeterministicHash(`${title}|${target}|${Date.now()}`);
    setPendingApproval({
      id: `appr_${Date.now()}`,
      title,
      target,
      risk,
      evidenceHash,
      reason,
      draftId,
    });
    setMorrowState('asking_approval');
    setActiveAnimAction('waiting_approval');

    const talk = evaluateMorrowTalkPolicy({
      trigger: 'approval_needed',
      focusModeActive: focusMode,
      dismissalCountForCategory: dismissalCount,
      proposedMessage: `Approval required: ${title}`,
    });
    setTalkLogs((prev) => [talk, ...prev.slice(0, 15)]);
  };

  const handleApproveAction = (channel: 'local_sheet' | 'telegram_phone') => {
    if (!pendingApproval) return;
    if (pendingApproval.draftId) {
      setApprovedDraftIds((prev) => [...prev, pendingApproval.draftId!]);
    }
    ledger.appendEvent({
      actor: 'user',
      type: 'approval_granted',
      summary: `User approved '${pendingApproval.title}' via ${channel === 'telegram_phone' ? 'Whitelisted Telegram Phone Bot' : 'Local Approval Sheet'}.`,
      payload: JSON.stringify({
        approvalId: pendingApproval.id,
        channel,
        target: pendingApproval.target,
        evidenceHash: pendingApproval.evidenceHash,
      }),
      trustLevel: 'user_stated',
      missionId: mission.id,
    });

    setPendingApproval(null);
    setMorrowState('done_with_proof');
    setActiveAnimAction('celebrate');
    setMission((prev) => ({ ...prev, state: 'COMPLETED' }));
    bumpLedger();
  };

  const handleRejectAction = () => {
    if (!pendingApproval) return;
    ledger.appendEvent({
      actor: 'user',
      type: 'approval_denied',
      summary: `User denied '${pendingApproval.title}'. Step halted cleanly.`,
      payload: JSON.stringify({
        approvalId: pendingApproval.id,
        target: pendingApproval.target,
      }),
      trustLevel: 'user_stated',
      missionId: mission.id,
    });
    setPendingApproval(null);
    setMorrowState('attentive');
    setActiveAnimAction('idle');
    bumpLedger();
  };

  const handleRecordUserCorrection = (correctionText: string, promoteToRule: boolean) => {
    ledger.appendEvent({
      actor: 'user',
      type: promoteToRule ? 'memory_promoted' : 'user_correction',
      summary: `User correction recorded${promoteToRule ? ' & compiled into Standing Rule' : ''}: "${correctionText}"`,
      payload: JSON.stringify({ correctionText, promoteToRule }),
      trustLevel: 'user_stated',
      missionId: mission.id,
    });

    if (promoteToRule) {
      setPolicyConfig((prev) => ({
        ...prev,
        standingRules: [
          {
            id: `rule-user-${prev.standingRules.length + 1}`,
            plainText: correctionText,
            compiledPattern: `guard.enforce("${correctionText.slice(0, 32)}")`,
            ruleType: 'require_approval',
            active: true,
            generatedScenario: `Verify "${correctionText}" halts matching proposal and asks approval`,
          },
          ...prev.standingRules,
        ],
      }));
    }
    bumpLedger();
  };

  const handleSubmitVoiceMission = (transcript: string) => {
    ringBuffer.push(`voice_asr: ${transcript.slice(0, 48)}`);
    ledger.appendEvent({
      actor: 'user',
      type: 'mission_started',
      summary: `Voice mission transcribed via muse-voice-transcribe-1.0 & verified by user: "${transcript}"`,
      payload: JSON.stringify({ transcript, model: 'muse-voice-transcribe-1.0' }),
      trustLevel: 'user_stated',
      missionId: 'mission-voice-ptt',
    });
    setMission((prev) => ({
      ...prev,
      objective: transcript,
      state: 'COMPLETED',
    }));
    setMorrowState('done_with_proof');
    setActiveAnimAction('celebrate');
    bumpLedger();
  };

  const handleRunGarbageCollection = () => {
    ledger.compactAndPruneQuarantined();
    ringBuffer.push('gc: compacted quarantined untrusted slots');
    bumpLedger();
  };

  const handleChangeProfile = (profile: BrowserProfileId) => {
    setPolicyConfig((prev) => ({ ...prev, activeProfileId: profile }));
    ringBuffer.push(`profile_switch: persist:${profile}`);
    bumpLedger();
  };

  const handleLogGuardDecisionToLedger = (decision: PolicyDecision, summary: string) => {
    ledger.appendEvent({
      actor: 'guard',
      type: decision.allowed ? 'action_allowed' : 'action_blocked',
      summary,
      payload: JSON.stringify(decision),
      trustLevel: 'verified_by_evidence',
      missionId: mission.id,
    });
    bumpLedger();
  };

  const handleRequestDraftApproval = (draft: MoneyActionDraft) => {
    handleRequestApproval(
      `Execute SIMULATION Draft: ${draft.currency} ${draft.amount.toFixed(2)} to ${draft.destination}`,
      `mockbank://transfer/simulation/${draft.id}`,
      'money',
      `Draft reference: "${draft.reference}". Real bank accounts stay strictly read-only; this executes as SIMULATION in MockBank only.`,
      draft.id
    );
  };

  const handleAddStandingRule = (plainText: string, maxAmount?: number) => {
    const newId = `rule-custom-${policyConfig.standingRules.length + 1}`;
    setPolicyConfig((prev) => ({
      ...prev,
      spendCapUsd: maxAmount ? Math.min(prev.spendCapUsd, maxAmount) : prev.spendCapUsd,
      standingRules: [
        {
          id: newId,
          plainText,
          compiledPattern: maxAmount ? `action.amount <= ${maxAmount}` : 'guard.custom_check()',
          ruleType: maxAmount ? 'spend_cap' : 'require_approval',
          maxAmount,
          active: true,
          generatedScenario: `Proposal exceeding ${maxAmount ? '$' + maxAmount : 'rule constraint'} -> Blocked by ${newId}`,
        },
        ...prev.standingRules,
      ],
    }));
    ledger.appendEvent({
      actor: 'user',
      type: 'memory_promoted',
      summary: `Compiled standing instruction '${newId}': ${plainText}`,
      payload: JSON.stringify({ newId, plainText, maxAmount }),
      trustLevel: 'user_stated',
      missionId: 'standing-rule-compiler',
    });
    bumpLedger();
  };

  const handleRunSleepCycle = (gateParams?: {
    appIsIdle: boolean;
    freeMemoryMb: number;
    thresholdMb: number;
  }) => {
    const rep = executeSleepCycle(ledger, gateParams);
    setSleepReport(rep);
    if (rep.promotionStatus !== 'DEFERRED_LOW_MEMORY_OR_BUSY') {
      setMorrowState('done_with_proof');
    }
    bumpLedger();
  };

  const handlePromoteCandidateSkill = () => {
    setSleepReport((prev) => ({ ...prev, promotionStatus: 'PROMOTED' }));
    setCompiledSkill((prev) => ({
      ...prev,
      version: Math.max(prev.version + 1, 2),
      baselineSuccessRate: 1.0,
    }));
    ledger.appendEvent({
      actor: 'user',
      type: 'approval_granted',
      summary: 'User approved & promoted Sleep Cycle Candidate Skill v2 (100% held-out pass rate, 0 regressions).',
      payload: JSON.stringify({ promotedSkillVersion: 2 }),
      trustLevel: 'user_stated',
      missionId: 'sleep-cycle-promotion',
    });
    bumpLedger();
  };

  const handleRollbackCandidateSkill = () => {
    setSleepReport((prev) => ({ ...prev, promotionStatus: 'ROLLED_BACK' }));
    setCompiledSkill((prev) => ({ ...prev, version: 1 }));
    bumpLedger();
  };

  const handleLogScheduleRunToLedger = (schedule: ScheduledMissionRecord) => {
    ledger.appendEvent({
      actor: 'agent',
      type: 'mission_started',
      summary: `Scheduled Mission '${schedule.title}' executed via Test Clock (${schedule.dynamicStepCountEstimate} dynamic steps, idempotencyKey=${schedule.idempotencyKey}).`,
      payload: JSON.stringify(schedule),
      trustLevel: 'verified_by_evidence',
      missionId: schedule.id,
    });
    setActiveAnimAction('celebrate');
    bumpLedger();
  };

  // Recompute derived ledger views on ledgerVersion change
  const ledgerEvents = useMemo(() => ledger.getEvents(), [ledger, ledgerVersion]);
  const chainReport = useMemo(() => ledger.verifyChain(), [ledger, ledgerVersion]);
  const memoryMetrics = useMemo(() => ledger.getEfficiencyMetrics(), [ledger, ledgerVersion]);

  return (
    <div className="min-h-screen flex flex-col bg-[#0B0F17] text-slate-100 pb-24">
      {/* Top Navigation Bar — Strictly follows 3-Zone Top Bar Contract */}
      <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-slate-800/90 bg-[#0B0F17]/95 sticky top-0 z-30 backdrop-blur-md">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#mission-control"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('mission_control');
          }}
          className="text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
        >
          Blaize
        </a>

        {/* Zone 2: 5 clean single-line text navigation links */}
        <nav
          aria-label="Primary Workspace Navigation"
          className="flex items-center gap-6 text-sm font-medium overflow-x-auto"
        >
          {[
            { id: 'mission_control' as ActiveWorkspaceTab, label: 'Mission Control' },
            { id: 'blaize_browser' as ActiveWorkspaceTab, label: 'Blaize Browser' },
            { id: 'l3xi_finance' as ActiveWorkspaceTab, label: 'L3xi Finance' },
            { id: 'trust_ledger' as ActiveWorkspaceTab, label: 'Trust & Ledger' },
            { id: 'evals_sleep' as ActiveWorkspaceTab, label: 'Studio & Evals' },
          ].map((nav) => {
            const isActive = activeTab === nav.id;
            return (
              <button
                key={nav.id}
                type="button"
                onClick={() => setActiveTab(nav.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                  isActive
                    ? 'border-sky-400 text-slate-100 font-semibold'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                {nav.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveTab('evals_sleep');
            }}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-sky-400 rounded-lg hover:bg-sky-300 transition-colors whitespace-nowrap shrink-0"
          >
            2D Assets &amp; Eval Suite
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 w-full max-w-[1380px] mx-auto px-4 sm:px-6 py-8">
        {activeTab === 'mission_control' && (
          <MissionControlView
            mission={mission}
            activeScenario={activeScenario}
            onSelectScenario={handleSelectScenario}
            onUpdateMissionState={handleUpdateMissionState}
            onTriggerApprovalForStep={(stepTitle, target, risk, reason) =>
              handleRequestApproval(stepTitle, target, risk, reason)
            }
            memoryMetrics={memoryMetrics}
            onRunGarbageCollection={handleRunGarbageCollection}
            ringBufferStats={{
              count: ringBuffer.toArray().length,
              capacity: ringBuffer.capacity,
              evictedCount: ringBuffer.evictedCount,
            }}
          />
        )}

        <Suspense
          fallback={
            <div className="bg-[#0F1623] border border-slate-800 rounded-xl p-6 text-xs font-mono text-sky-400">
              Loading lazy feature module into memory on demand...
            </div>
          }
        >
          {activeTab === 'blaize_browser' && (
            <BlaizeBrowserView
              activeProfile={policyConfig.activeProfileId}
              onChangeProfile={handleChangeProfile}
              policyConfig={policyConfig}
              compiledSkill={compiledSkill}
              onUpdateCompiledSkill={(skill) => {
                setCompiledSkill(skill);
                ledger.appendEvent({
                  actor: 'user',
                  type: 'memory_promoted',
                  summary: `Compiled Teach & Replay Skill '${skill.name}' v${skill.version}.`,
                  payload: JSON.stringify({ skillId: skill.id, version: skill.version }),
                  trustLevel: 'user_stated',
                  missionId: 'teach-studio',
                });
                bumpLedger();
              }}
              onLogGuardDecisionToLedger={handleLogGuardDecisionToLedger}
              onRequestApproval={(title, target, risk, reason) =>
                handleRequestApproval(title, target, risk, reason)
              }
            />
          )}

          {activeTab === 'l3xi_finance' && (
            <L3xiFinanceView
              onRequestDraftApproval={handleRequestDraftApproval}
              approvedDraftIds={approvedDraftIds}
            />
          )}

          {activeTab === 'trust_ledger' && (
            <TrustAndLedgerView
              events={ledgerEvents}
              chainReport={chainReport}
              isTampered={ledger.isTampered()}
              onSimulateTamper={() => {
                ledger.simulateTamper(1);
                bumpLedger();
              }}
              onRestoreTamper={() => {
                ledger.restoreTamperedEvent();
                bumpLedger();
              }}
              onDeleteLedgerContent={(contentRef) => {
                ledger.deleteContent(contentRef);
                bumpLedger();
              }}
              onExplainEvent={(id) => ledger.explain(id)}
              policyConfig={policyConfig}
              onAddStandingRule={handleAddStandingRule}
              onLogPluginGuardBlock={(pluginId, summary) => {
                ledger.appendEvent({
                  actor: 'guard',
                  type: 'plugin_blocked',
                  summary,
                  payload: JSON.stringify({ pluginId, summary }),
                  trustLevel: 'verified_by_evidence',
                  missionId: 'plugin-sandbox-guard',
                });
                bumpLedger();
              }}
            />
          )}

          {activeTab === 'evals_sleep' && (
            <div className="space-y-8">
              <LivingDesktopStudioPanel
                companionName={companionName}
                setCompanionName={setCompanionName}
                activeLookId={activeLookId}
                setActiveLookId={setActiveLookId}
                activeAnimAction={activeAnimAction}
                onTriggerAnimationAction={handleTriggerAnimationAction}
                compiledPersonality={compiledPersonality}
                onUpdateCompiledPersonality={setCompiledPersonality}
                isPlayingMusic={isPlayingMusic}
                setIsPlayingMusic={setIsPlayingMusic}
                activeTrack={activeTrack}
                setActiveTrack={setActiveTrack}
                danceSyncEnabled={danceSyncEnabled}
                setDanceSyncEnabled={setDanceSyncEnabled}
                onLogScheduleRunToLedger={handleLogScheduleRunToLedger}
              />

              <EvalsAndSleepView
                sleepReport={sleepReport}
                onRunSleepCycle={handleRunSleepCycle}
                onPromoteCandidateSkill={handlePromoteCandidateSkill}
                onRollbackCandidateSkill={handleRollbackCandidateSkill}
              />
            </div>
          )}
        </Suspense>
      </main>

      {/* Quiet Footer (No Ornamental Telemetry Tickers) */}
      <footer className="border-t border-slate-800/80 px-6 py-4 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-4 max-w-[1380px] w-full mx-auto">
        <div>
          Blaize v3 — The Accountable Living AI Desktop · 2D Anime Rig · Music &amp; Dance Sync · User-Owned Memory Ledger
        </div>
        <div className="font-mono text-[11px] text-slate-500">
          CC0 2D Rig Assets Bundled · Zero Committed Secrets · &lt;24 GB RAM Governance Enforced
        </div>
      </footer>

      {/* Floating Morrow 2D Anime Companion & Approval Sheet */}
      <MorrowCompanion
        morrowState={morrowState}
        setMorrowState={setMorrowState}
        personalityId={personalityId}
        setPersonalityId={setPersonalityId}
        talkLogs={talkLogs}
        focusMode={focusMode}
        setFocusMode={setFocusMode}
        onDismissNotification={() => setDismissalCount((c) => c + 1)}
        dismissalCount={dismissalCount}
        pendingApproval={pendingApproval}
        onApproveAction={handleApproveAction}
        onRejectAction={handleRejectAction}
        onRecordUserCorrection={handleRecordUserCorrection}
        onSubmitVoiceMission={handleSubmitVoiceMission}
        companionName={companionName}
        activeAnimAction={activeAnimAction}
        onChangeAnimAction={handleTriggerAnimationAction}
        isPlayingMusic={isPlayingMusic}
        onToggleMusic={() => {
          const next = !isPlayingMusic;
          setIsPlayingMusic(next);
          if (next && danceSyncEnabled) {
            handleTriggerAnimationAction('dance', 'Music started from companion bar');
          } else if (!next && activeAnimAction === 'dance') {
            handleTriggerAnimationAction('idle', 'Music paused from companion bar');
          }
        }}
        onOpenStudioFileManager={() => setActiveTab('evals_sleep')}
      />
    </div>
  );
}
